# Summary

* [Python 基础课程安排](README.md)
  * [操作系统（科普章节）](linux/操作系统（科普章节）.md)
  * [操作系统的发展史（科普章节）](linux/操作系统的发展史（科普章节）.md)
  * [文件和目录（理解）](linux/文件和目录（理解）.md)
  * [Ubuntu 图形界面入门](linux/Ubuntu 图形界面入门.md)
  * [常用 Linux 命令的基本使用](linux/常用 Linux 命令的基本使用.md)
  * [Linux 终端命令格式](linux/Linux 终端命令格式.md)
  * [文件和目录常用命令](linux/文件和目录常用命令.md)
  * [远程管理常用命令](linux/远程管理常用命令.md)
  * [用户权限相关命令](linux/用户权限相关命令.md)
  * [系统信息相关命令](linux/系统信息相关命令.md)
  * [其他命令](linux/其他命令.md)

